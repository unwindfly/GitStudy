# 常用API

### **常用字符判断API**

```cpp
int isalnum ( int c );
/*
Checks whether *c* is either a decimal digit or an uppercase or lowercase letter.
Return Value
A value different from zero (i.e., true) if indeed c is either a digit or a letter. Zero (i.e., false) otherwise.
*/

int isalpha ( int c );
/*
Checks whether c is an alphabetic letter.
Return Value
A value different from zero (i.e., true) if indeed c is an alphabetic letter. Zero (i.e., false) otherwise.
*/

int isblank ( int c );
/*
Checks whether c is a blank character.
Return Value
A value different from zero (i.e., true) if indeed c is a blank character. Zero (i.e., false) otherwise.
*/

int isdigit ( int c );
/*
Checks whether c is a decimal digit character.
Return Value
A value different from zero (i.e., true) if indeed c is a decimal digit. Zero (i.e., false) otherwise.
*/

int islower ( int c );
/*
Checks whether c is a lowercase letter.
Return Value
A value different from zero (i.e., true) if indeed c is a lowercase alphabetic letter. Zero (i.e., false) otherwise.
*/

int isspace ( int c );
/*
Checks whether c is a white-space character.
For the "C" locale, white-space characters are any of:
' '	(0x20)	space (SPC)
'\t'	(0x09)	horizontal tab (TAB)
'\n'	(0x0a)	newline (LF)
'\v'	(0x0b)	vertical tab (VT)
'\f'	(0x0c)	feed (FF)
'\r'	(0x0d)	carriage return (CR)
Return Value
A value different from zero (i.e., true) if indeed c is a white-space character. Zero (i.e., false) otherwise.
*/

int isupper ( int c );
/*
Checks if parameter c is an uppercase alphabetic letter.
Return Value
A value different from zero (i.e., true) if indeed c is an uppercase alphabetic letter. Zero (i.e., false) otherwise.
*/

int isxdigit ( int c );
/*
Checks whether c is a hexdecimal digit character.
Hexadecimal digits are any of: 0 1 2 3 4 5 6 7 8 9 a b c d e f A B C D E F
Return Value
A value different from zero (i.e., true) if indeed c is a hexadecimal digit. Zero (i.e., false) otherwise.
*/

int tolower ( int c );
/*
Converts c to its lowercase equivalent if c is an uppercase letter and has a lowercase equivalent. If no such conversion is possible, the value returned is c unchanged.
*/

int toupper ( int c );
/*
Converts c to its uppercase equivalent if c is a lowercase letter and has an uppercase equivalent. If no such conversion is possible, the value returned is c unchanged.
*/
```



```cpp
int atoi (const char * str);
/*
Convert string to integer
Return Value
On success, the function returns the converted integral number as an int value.
If the converted value would be out of the range of representable values by an int, it causes undefined behavior. See strtol for a more robust cross-platform alternative when this is a possibility.
*/

const char * strstr ( const char * str1, const char * str2 );
      char * strstr (       char * str1, const char * str2 );
/*
Locate substring
Returns a pointer to the first occurrence of str2 in str1, or a null pointer if str2 is not part of str1.
*/

int strcmp ( const char * str1, const char * str2 );
/*
Compares the C string str1 to the C string str2.
Returns an integral value indicating the relationship between the strings:
return value	indicates
<0	the first character that does not match has a lower value in ptr1 than in ptr2
0	the contents of both strings are equal
>0	the first character that does not match has a greater value in ptr1 than in ptr2
*/

char * strcat ( char * destination, const char * source );
/*
Concatenate strings
Appends a copy of the source string to the destination string. The terminating null character in destination is overwritten by the first character of source, and a null-character is included at the end of the new string formed by the concatenation of both in destination.
*/


char * strncat ( char * destination, const char * source, size_t num );
/*
Append characters from string
Appends the first num characters of source to destination, plus a terminating null-character.
*/

int stoi (const string&  str, size_t* idx = 0, int base = 10);
int stoi (const wstring& str, size_t* idx = 0, int base = 10);
/*
Convert string to integer
Parses str interpreting its content as an integral number of the specified base, which is returned as an int value.

If idx is not a null pointer, the function also sets the value of idx to the position of the first character in str after the number.
Return Value
On success, the function returns the converted integral number as an int value.
*/

double stod (const string&  str, size_t* idx = 0);
float stof (const string&  str, size_t* idx = 0);
long stol (const string&  str, size_t* idx = 0, int base = 10);
long double stold (const string&  str, size_t* idx = 0);
long long stoll (const string&  str, size_t* idx = 0, int base = 10);
unsigned long stoul (const string&  str, size_t* idx = 0, int base = 10);
unsigned long long stoull (const string&  str, size_t* idx = 0, int base = 10);


std::to_string
string to_string (int val);
string to_string (long val);
string to_string (long long val);
string to_string (unsigned val);
string to_string (unsigned long val);
string to_string (unsigned long long val);
string to_string (float val);
string to_string (double val);
string to_string (long double val);
/*
Convert numerical value to string
Return Value
A string object containing the representation of val as a sequence of characters.
*/


string (1)	
size_t find (const string& str, size_t pos = 0) const noexcept;
c-string (2)	
size_t find (const char* s, size_t pos = 0) const;
buffer (3)	
size_t find (const char* s, size_t pos, size_type n) const;
character (4)	
size_t find (char c, size_t pos = 0) const noexcept;
/*
Find content in string
Searches the string for the first occurrence of the sequence specified by its arguments.
*/
```

